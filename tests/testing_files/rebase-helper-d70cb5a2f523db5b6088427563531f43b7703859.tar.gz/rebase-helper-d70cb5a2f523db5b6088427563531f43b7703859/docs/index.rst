.. mdinclude:: ../README.md

.. toctree::
   :hidden:

   Home <self>
   User Guide <user_guide/index>
   API <api/index>
   Change Log <changelog>
