Usage
=====

.. autoargs::
   :function: CLI.build_parser
   :module: rebasehelper.cli
   :program_name: rebase-helper
   :synopsis_max_width: 72

   DESCRIPTION : @replace
      .. include:: ../description.rst

   OPTION : -h : @replace
      show help message and exit
