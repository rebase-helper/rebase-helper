Exception module
================

.. automodule:: rebasehelper.exceptions
   :members:
   :undoc-members:
