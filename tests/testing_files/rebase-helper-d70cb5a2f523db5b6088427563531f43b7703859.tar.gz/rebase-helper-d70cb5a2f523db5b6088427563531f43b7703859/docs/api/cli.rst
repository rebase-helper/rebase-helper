CLI module
==========

.. automodule:: rebasehelper.cli
   :members:
   :undoc-members:
