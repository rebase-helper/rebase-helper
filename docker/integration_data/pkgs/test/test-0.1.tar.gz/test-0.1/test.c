/*
 * this is variable A
 */
int variableA = 0;

/*
 * this is variable B
 */
int variableB = 0;

/*
 * this is variable C
 */
int variableC = 0;

/*
 * this is function X
 */
int functionX(void)
{
    return 42;
}
