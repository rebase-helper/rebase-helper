void function(void)
{
    return;
}
