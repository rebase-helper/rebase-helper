/*
 * this is variable A
 */
int variableA = -1;

/*
 * this is variable B
 */
int variableB = 0;

/*
 * this is function X
 */
int functionX(void)
{
    return 42;
}

/*
 * this is function Y
 */
void functionY(void)
{
    return;
}
