Exception module
===================

.. automodule:: rebasehelper.exception
   :members:
   :undoc-members:
