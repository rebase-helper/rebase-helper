Patch helper module
===================

.. automodule:: rebasehelper.patch_helper
   :members:
   :undoc-members:
