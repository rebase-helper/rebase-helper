Base output module
===================

.. automodule:: rebasehelper.base_output
   :members:
   :undoc-members:
